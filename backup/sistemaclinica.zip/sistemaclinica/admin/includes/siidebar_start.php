<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Painel</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="index.php">Painel</a></li>							
						</ul>
                    </li> 
                     <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Paciente</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="paciente.php">Pacientes</a></li>							
						</ul>
                    </li> 
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Medicos</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="medicos.php">Medicos</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Consultas</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="lista_marcacoes.php">Lista de Marcação</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Administrador</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="admin_user.php">Administrador</a></li>
							<li><a href="perfil.php">Meu perfil</a></li>
						</ul>
                    </li>       
                    		
                </ul>
				
			</div>
        </div>
<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Painel</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="index.php">Painel</a></li>							
						</ul>
                    </li> 
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Medicos</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="configuracao.php">Medicos</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Consultas</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="lista_marcacoes.php">Lista de Marcação</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Relatorios</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="relatorios.php">Lista de Relatorios</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Receita</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="receita.php">Lista de receitas</a></li>
						</ul>
                    </li>	
                </ul>
				
			</div>
        </div>
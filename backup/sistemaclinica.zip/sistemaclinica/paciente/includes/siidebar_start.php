<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Painel</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="index.php">Painel</a></li>							
						</ul>
                    </li> 
                     <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Perfil</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="perfil.php">Pacientes</a></li>
							<li><a href="configuracao.php">Configuração</a></li>							
						</ul>
                    </li> 
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Consultas</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="lista_marcacoes.php">Lista de Marcação</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Relatorios</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="relatorios.php">Lista de Relatorios</a></li>
						</ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Receitas</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="receitas.php">Lista de Receitas</a></li>
						</ul>
                    </li>			
                </ul>
				
			</div>
        </div>